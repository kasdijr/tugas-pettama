<?php

$conn = mysqli_connect("localhost", "root", "novenhysx", "pembukaan");

if (!$conn) {
    die("Koneksi Gagal : " . mysqli_connect_error());
}
